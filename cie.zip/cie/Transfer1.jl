module Transfer1

# Calculation for 1st order functions

function transfer_function(num::Int)::Float64
	M, R, T = get_param(num)
    j = 1/2*M*(R^2)
    R = 2.08
    println("number: ", num, ", coefficient value: ",2.08*j)
	return 2.08*j
end

function get_param(num::Int)
	M::Float64 = 0
	R::Float64 = 0
	T::Float64 = 0
    if num == 6
        M = 127 * 10^(-3)
        R = 55/2 * 10^(-3)
        T = 20 * 10^(-3)
	elseif num == 9
        M = 63*10^(-3)
        R = 55/2 * 10^(-3)
        T = 10*10^(-3)
	elseif num == 8
		M = 102*10^(-3)
		R = 40/2 * 10^(-3)
		T = 30*10^(-3)
    else
        exit(1)
	end
    return M, R, T
end
println("k_t * k_m = ", 0.0243*0.0242)

println("simplify numerator:", 0.0243/0.00058806)
println("simplify coefficient of s (#6): ", transfer_function(6)/0.0243*0.0242)

println("simplify coefficient of s (#8): ", transfer_function(8)/0.00058806)
println("simplify coefficient of s (#9): ", transfer_function(9)/0.00058806)




end
