module Transferh

function percentage_overshoot(num::Int, input::Int)

	y_max::Float64  = 0
	t_p::Float64  = 0
	R_0::Float64  = 0

	if num == 8 && input == 6
		y_max = 9.30
		t_p = 0.294
		R_0 = 6
	elseif num == 6 && input == 6
		y_max = 9.59
		t_p = 0.265
		R_0 = 6
	end

	return (y_max- R_0)/R_0
end


function damp(po::Float64)
	val = log(po/100)/π
	ζ = √(val^2/(1+val^2))
	return ζ
end

function natural_freq(ζ::Float64, t_p::Float64)
	return (π/(t_p*√(1-ζ^2))) 
end


ζ_8= (damp ∘ percentage_overshoot)(8, 6)
t_8 = 0.294
println("\npercentage_overshoot: #8 (step input = 6 rad) \n", percentage_overshoot(8, 6))
println("damp param #8 (step input = 6 rad) \n", ζ_8)
println("natural freq #8 (step input = 6 rad) \n", natural_freq(ζ_8, t_8))


println("\n--------------------------------\n")
ζ_6= (damp ∘ percentage_overshoot)(6, 6)
t_6 = 0.265
println("percentage_overshoot: #6 (step input = 6 rad) \n", percentage_overshoot(6, 6))
println("damp param #6 (step input = 6 rad) \n", ζ_6)
println("natural freq #6 (step input = 6 rad) \n", natural_freq(ζ_6, t_6), "\n")

end
